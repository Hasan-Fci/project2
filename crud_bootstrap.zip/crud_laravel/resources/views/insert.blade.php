<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Show Data</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
	<form action="/save" method="get">
	<table align="center" width="700" border="1" cellpadding="5" cellspacing="0">
		<tr>
			<th>Name</th>
			<td><input class="form-control" type="text" name="name"></td>
		</tr>
			<tr>
			<th>Mobile</th>
			<td><input class="form-control" type="text" name="mobile"></td>
		</tr>
			<tr>
			<th>Salary</th>
			<td><input class="form-control" type="text" name="salary"></td>
		</tr>
		</tr>
			<tr>
			<th>Address</th>
			<td><textarea class="form-control" name="address" cols="20" rows="3"></textarea></td>
		</tr>
		</tr>
			<tr>

			<td colspan="2">
				<input class="btn btn-primary" type="submit" value="Save" name="save">
			</td>
		</tr>
	</table>
</form>
</body>
</html>