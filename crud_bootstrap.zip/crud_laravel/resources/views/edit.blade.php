<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Edit Pages</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
	<form action="/process" method="get">
		<table align="center" width="700" border="1" cellpadding="5" cellspacing="0">
			<tr>
				<th>Name</th>
				<td><input class="form-control" type="text" name="name" value="<?=$student->name;?>"></td>
			</tr>
			<tr>
				<th>Mobile</th>
				<td><input class="form-control" type="text" name="mobile" value="<?=$student->mobile;?>"></td>
			</tr>
			<tr>
				<th>Salary</th>
				<td><input class="form-control" type="text" name="salary" value="<?=$student->salary;?>"></td>
			</tr>
			<tr>
				<th>Address</th>
				<td><textarea  class="form-control" name="address" cols="20" rows="3"><?=$student->address;?></textarea></td>
			</tr>
			<tr>
				<td colspan="2">
					<input type="hidden" name="id" value="<?=$student->id;?>">
					<input class="btn btn-info" type="submit" name="save" value="Update">
				</td>
			</tr>
		</table>
	</form>
</body>
</html>