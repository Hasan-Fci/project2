<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>cred laravel</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
	<table align="center" border="1" width="700" cellpadding="5" cellspacing="0">
		<thead>
			<tr>
				<td colspan="6"><span style="color: blue;">Laravel 5.6 Crud Operation</span> &nbsp;&nbsp;<a class="btn btn-success" href="/insert" style="float: right;">Add New Student</a></td>
			</tr>
			<tr>
				<th>Id</th>
				<th>Name</th>
				<th>Mobile</th>
				<th>Salary</th>
				<th>Address</th>
				<th>Action</th>
			</tr>
<?php
foreach ($students as $student) {
	?>
			<tr>
				<td><?=$student->id;?></td>
				<td><?=$student->name;?></td>
				<td><?=$student->mobile;?></td>
				<td><?=$student->salary;?></td>
				<td><?=$student->address;?></td>
				<td><a class="btn btn-info btn-sm" href="/edit/<?=$student->id;?>">Edit</a>&nbsp;&nbsp;<a class="btn btn-danger btn-sm" onclick="return confirm('Are you sure to Delete !!')" href="/delete/<?=$student->id;?>">Delete</a></td>
			</tr>
<?php
}
?>
		</thead>
	</table>
</body>
</html>