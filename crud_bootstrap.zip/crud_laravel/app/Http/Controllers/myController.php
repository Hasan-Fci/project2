<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class mycontroller extends Controller {
	//
	public function index() {

		$data = DB::table('students')->get();
		return view('read', ['students' => $data]);
	}

	public function edit($id) {
		$student = DB::table('students')->where('id', $id)->first();
		return view('edit', ["student" => $student]);

	}

	public function delete($id) {
		$data = DB::table('students')->where('id', $id)->delete();
		if ($data) {
			return redirect("/read");
		} else {
			echo "Delete Fail";
		}

	}

	public function process(Request $request) {

		$data = DB::table('students')->where('id', $request->id)->update(['name' => $request->name, 'mobile' => $request->mobile, 'salary' => $request->salary, 'address' => $request->address]);

		//echo $data?"Data Update Success":"Data Update Fail";
		if ($data) {
			return redirect("/read");
		} else {
			echo "Update Fail";
		}

	}

	public function save(Request $request) {

		$data = DB::table('students')->insert(['name' => $request->name, 'mobile' => $request->mobile, 'salary' => $request->salary, 'address' => $request->address]);

		//echo $data?"Data Update Success":"Data Update Fail";
		if ($data) {
			return redirect("/read");
		} else {
			echo "Insert Fail";
		}

	}

	public function form() {
		return view("form");
	}

	public function insert() {

		return view('insert');
	}
}
