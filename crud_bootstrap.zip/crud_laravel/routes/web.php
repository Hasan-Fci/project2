<?php

Route::get('/', function () {
	return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

/*laravel crud*/

Route::get('/read', 'myController@index');
Route::get('/edit/{id}', 'myController@edit');
Route::get('/process', 'myController@process');
Route::get('/insert', 'myController@insert');
Route::get('/save', 'myController@save');
Route::get('/delete/{id}', 'myController@delete');

/*laravel crud*/
